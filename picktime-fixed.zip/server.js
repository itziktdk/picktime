const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const mongoose = require('mongoose');
const rateLimit = require('express-rate-limit');
const compression = require('compression');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// 🔒 Security & Performance
app.use(helmet());
app.use(compression());
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
  credentials: true
}));

// 📊 Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests, please try again later.'
});
app.use('/api/', limiter);

// 📦 Middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// 🗄️ MongoDB Connection - Use local fallback for demo
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/picktime';

mongoose.connect(MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => {
  console.log('🔗 Connected to MongoDB');
}).catch(err => {
  console.warn('⚠️ MongoDB connection failed, running without database:', err.message);
  // Continue without database for demo purposes
});

// 📋 Models
const Business = require('./models/Business');
const Service = require('./models/Service');
const Appointment = require('./models/Appointment');
const Customer = require('./models/Customer');
const Provider = require('./models/Provider');

// 🎨 Theme configurations
const themes = {
  beauty: {
    name: 'מכון יופי',
    colors: {
      primary: '#FF6B9D', // Pink
      secondary: '#C44569', // Deep pink
      accent: '#F8B500', // Gold
      background: '#FFF5F8', // Light pink
      surface: '#FFFFFF',
      text: '#2C2C54'
    },
    icon: 'sparkles'
  },
  hair: {
    name: 'מספרה',
    colors: {
      primary: '#6C5CE7', // Purple
      secondary: '#A29BFE', // Light purple
      accent: '#FD79A8', // Pink accent
      background: '#F8F7FF', // Very light purple
      surface: '#FFFFFF',
      text: '#2D3436'
    },
    icon: 'scissors'
  },
  fitness: {
    name: 'כושר ואימונים',
    colors: {
      primary: '#00B894', // Green
      secondary: '#00CEC9', // Turquoise
      accent: '#FDCB6E', // Yellow
      background: '#F0FFF4', // Light green
      surface: '#FFFFFF',
      text: '#2D3436'
    },
    icon: 'fire'
  },
  tutoring: {
    name: 'שיעורים פרטיים',
    colors: {
      primary: '#0984E3', // Blue
      secondary: '#74B9FF', // Light blue
      accent: '#E17055', // Orange
      background: '#F0F8FF', // Light blue
      surface: '#FFFFFF',
      text: '#2D3436'
    },
    icon: 'academic-cap'
  },
  medical: {
    name: 'שירותי בריאות',
    colors: {
      primary: '#00B894', // Medical green
      secondary: '#55A3FF', // Medical blue
      accent: '#FF7675', // Medical red
      background: '#F8FFFA', // Very light green
      surface: '#FFFFFF',
      text: '#2D3436'
    },
    icon: 'heart'
  },
  tech: {
    name: 'שירותים טכניים',
    colors: {
      primary: '#636E72', // Gray
      secondary: '#74B9FF', // Blue
      accent: '#FDCB6E', // Yellow
      background: '#F8F9FA', // Light gray
      surface: '#FFFFFF',
      text: '#2D3436'
    },
    icon: 'cog'
  }
};

// 🔄 API Routes
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    service: 'PickTime API',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// 🎨 Get available themes
app.get('/api/themes', (req, res) => {
  res.json(themes);
});

// 🏢 Business routes
app.post('/api/businesses', async (req, res) => {
  try {
    const business = new Business(req.body);
    await business.save();
    res.status(201).json(business);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get('/api/businesses/:slug', async (req, res) => {
  try {
    const business = await Business.findOne({ slug: req.params.slug })
      .populate('services')
      .populate('providers');
    if (!business) {
      return res.status(404).json({ error: 'Business not found' });
    }
    res.json(business);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 📅 Appointment routes
app.post('/api/appointments', async (req, res) => {
  try {
    const appointment = new Appointment(req.body);
    await appointment.save();
    res.status(201).json(appointment);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get('/api/appointments/:businessId', async (req, res) => {
  try {
    const appointments = await Appointment.find({ 
      business: req.params.businessId 
    })
    .populate('customer')
    .populate('service')
    .populate('provider')
    .sort({ dateTime: 1 });
    
    res.json(appointments);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 👥 Customer routes
app.post('/api/customers', async (req, res) => {
  try {
    const customer = new Customer(req.body);
    await customer.save();
    res.status(201).json(customer);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// 🎯 Services routes
app.get('/api/services/:businessId', async (req, res) => {
  try {
    const services = await Service.find({ business: req.params.businessId });
    res.json(services);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 📱 Main client app route
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/index.html');
});

// 🌟 Business booking page route
app.get('/:slug', async (req, res) => {
  try {
    const business = await Business.findOne({ slug: req.params.slug });
    if (!business) {
      return res.status(404).sendFile(__dirname + '/public/404.html');
    }
    res.sendFile(__dirname + '/public/booking.html');
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// 🚀 Server startup
app.listen(PORT, () => {
  console.log(`🔥 PickTime server running on port ${PORT}`);
  console.log(`🌐 Health check: http://localhost:${PORT}/api/health`);
  console.log(`📱 Web app: http://localhost:${PORT}`);
});

module.exports = app;